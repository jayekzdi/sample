<?php
define('user','root');
define('password','');
define('host','127.0.0.1');
define('name', 'kcs');
$connect=mysqli_connect(host,user,password,name);
?>