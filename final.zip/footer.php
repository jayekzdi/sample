   <footer>
                <div class="col-md-12" style="background-color: #222; color: white;">
                    <div class="col-md-4">
                    <ul class="nav footnav">
                         <li><a href="package.php">PACKAGE</a></li>
                        <?php echo disp1(); ?>
                         <li><a href="contactus.php">CONTACT US</a></li>
                    </ul>
                </div><!--col md 4-->
                        <p class="tag"><center>
                        <a href=""><i class="fa fa-facebook"></i></a><br><br>
                    Develop By: KCS Team</center></p>
                </div>

    </footer>