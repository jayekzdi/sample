<?php
include '../functions.php';
echo approve($connect);
?>