function dtpck(){
	$('#bday-dtpicker').datetimepicker({
		format:'LD'
	});
		
}
