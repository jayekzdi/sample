 <div class="row row-offcanvas row-offcanvas-left">
        <div class="col-xs-6 col-sm-3 sidebar-offcanvas" id="sidebar" role="navigation">
            <div class="sidebar-nav">
                <ul class="nav">
                    <li class="active" id="res_toggle"><a href="#">RESERVATIONS</a></li>
                    <li>
                    	<ul id="res_id">
                    		<li><a href="pending_res.php">Pending Resevations</a></li>
                 			<li><a href="admin_res.php">View Reservations</a></li>

                    	</ul>
                    </li>
                    <li><a href="#" id="pax_toggle">PACKAGE</a></li>
                    <li>
                    	<ul id="pax_id">
                    		<li><a href="side_dish.php">Side Dishes</a></li>
                 			<li><a id="main_toggle">Main Dishes</a></li>
                 			<li class="nav">
                 			<ul id="main_id">
                    		<li><a href="main_dish_pork.php">Pork</a></li>
                 			<li><a href="main_dish_beef.php">Beef</a></li>
                 			<li><a href="main_dish_chicken.php">Chicken</a></li>
                 			<li><a href="main_dish_seafood.php">Seafoods</a></li>
                    	</ul>
                    </li>
                 			<li><a href="dessert.php">Dessert</a></li>
                 			<li><a href="drinks.php">Drinks</a></li>
                 			<li><a href="soup.php">Soup</a></li>
                    	</ul>
                    </li>
                    <li><a href="#" id="ads_toggle">ADS</a></li>
                     <li><ul id="ads_id">
                    		<li><a href="ads_events.php">Add Events</a></li>
                 			<li><a href="ads_image.php">Add Pictures</a></li>
                    	</ul>
                    </li>
                    <li><a href="user_account.php">ACCOUNTS</a></li>
                    <li><a href="report.php">REPORTS</a></li>
                    <li class="nav-divider"></li>
                </ul>
            </div>
            <!--/.well -->
        </div>
        <!--/span-->	