<?php
include '../functions.php';
echo $_POST["main_dish_name"];
?>